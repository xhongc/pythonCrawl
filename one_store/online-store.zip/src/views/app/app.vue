<template>

    <div>
        <router-view name = "head"></router-view>
        <router-view name ='content'></router-view>
        <router-view name = 'footer'></router-view> 
    </div>
  
</template>
<script>

</script>
<style  lang='scss'>

</style>
