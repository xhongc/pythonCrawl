from django.contrib import admin
from api.models import UserAdmin
# Register your models herree.
admin.site.register(UserAdmin)
