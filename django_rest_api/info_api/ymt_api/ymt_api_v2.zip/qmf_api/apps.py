from django.apps import AppConfig


class QmfApiConfig(AppConfig):
    name = 'qmf_api'
