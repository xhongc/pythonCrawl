from django.contrib import admin
from qmf_api.models import Wxsession

# Register your models here.


admin.site.register(Wxsession)
